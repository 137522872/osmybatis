create view b2b_agentb2b as
  select
    `ag`.`id`         AS `id`,
    `ag`.`userName`   AS `username`,
    `ag`.`realName`   AS `full_name`,
    `ag`.`mobileNo`   AS `cellphone`,
    `ag`.`levelCode`  AS `level_code`,
    `ag`.`levelName`  AS `level_name`,
    `ag`.`createDate` AS `create_date`
  from `dxh_b2b`.`salesman` `ag`
  where (`ag`.`vendorId` <> 17)
  order by `ag`.`id`;

